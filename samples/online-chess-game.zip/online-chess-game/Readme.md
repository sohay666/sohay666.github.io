# Installation Guide
Node version is 16.20.2
```
npm install
npm start
```

# Problem
First of all, set the node version<br>
We will review not only your code optimization but also your coding style and coding speed.<br>
Find the AI ​​monkey part in your React component.<br>
And you should optimize the code in the component.<br>
You don't need to optimize all the functions. It's enough for some special functions.
