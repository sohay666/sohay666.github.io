import MatchPlayLogin from "../../components/UI/MatchPlayLogin/MatchPlayLogin";

export const MatchPlay = () => {
    return (
        <MatchPlayLogin />
    )
}

export default MatchPlay;