export const apiServerPort = 8050;

export const socketServerPort = 8050;